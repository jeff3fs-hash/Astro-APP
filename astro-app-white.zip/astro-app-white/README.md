# Astro App — Site White

Site institucional white pra cadastrar produto na Hotmart.

## Estrutura

```
astro-app-white/
├── index.html      # Home — hero + features + processo + CTA
├── about.html      # Acerca de — sobre o serviço, princípios
├── contact.html    # Contacto — info + formulário
├── privacy.html    # Política de Privacidade
├── terms.html      # Términos de Uso
└── access.html     # Página pós-compra (link da Hotmart aponta pra cá)
```

## Stack

- HTML estático puro (sem build, sem dependências)
- Google Fonts (Cormorant Garamond + Manrope)
- CSS inline em cada página (autocontido)
- Mobile responsive
- Idioma: Espanhol neutro LATAM

## Design

- **Aesthetic**: editorial sofisticado, tipo "Bloomberg / The Atlantic"
- **Cores**: midnight blue (#0F1729) + cream (#F8F5EE) + gold (#C9A961)
- **Tipografia**: Cormorant Garamond (display serif) + Manrope (body sans)

Posicionamento: **serviço profissional de análise astrológica**. Zero palavras místicas (alma gemela, brujería, hechizo, etc).

## Como hospedar (3 opções)

### Opção A — Cloudflare Pages (recomendado, grátis)

```bash
# 1. Cria repo no GitHub e push
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/SEU_USER/astro-app-white
git push -u origin main

# 2. Cloudflare Dashboard → Pages → Create project → Connect to Git
# 3. Seleciona repo, deixa todas as configs em branco (HTML estático)
# 4. Deploy automático em ~1 min
# 5. Cloudflare te dá URL: https://astro-app-white.pages.dev
# 6. (Opcional) Custom domain: astroapp.com
```

### Opção B — Hostinger / cPanel

1. Painel Hostinger → File Manager
2. Vai pra `public_html/`
3. Upload os 6 arquivos
4. Pronto, site no ar em https://seudominio.com

### Opção C — Vercel / Netlify

```bash
# Vercel
npm i -g vercel
vercel
```

## Configurar na Hotmart

1. **Cadastrar produto**:
   - Nome do produto: `Astro App - Análisis Personalizado`
   - Categoria: `Otros / Educação`
   - Preço: defina o teu
   - Idioma: Espanhol

2. **Página de vendas** (Sales Page):
   - URL: `https://astroapp.com/` (a home)

3. **Página de obrigado / Acesso ao produto** (Thank You / Access URL):
   - URL: `https://astroapp.com/access.html?email={BUYER_EMAIL}&transaction={TRANSACTION_ID}`
   - ⚠️ Confere no painel da Hotmart o nome exato das variáveis (pode ser `{COMPRADOR_EMAIL}` ou `{BUYER_EMAIL}`)

4. **Política de Privacidade**:
   - URL: `https://astroapp.com/privacy.html`

5. **Termos de Uso**:
   - URL: `https://astroapp.com/terms.html`

6. **Contato**:
   - URL: `https://astroapp.com/contact.html`
   - Email: `soporte@astroapp.com` (configura no teu provedor de email)

## O que substituir antes de subir

Busca por `astroapp.com` em todos os arquivos e troca pelo teu domínio real.

Busca por `soporte@astroapp.com` e troca pelo email real de suporte.

```bash
# No Linux/Mac:
find . -name "*.html" -exec sed -i 's/astroapp.com/SEU-DOMINIO.com/g' {} +
find . -name "*.html" -exec sed -i 's/soporte@astroapp.com/SEU-EMAIL@DOMINIO.com/g' {} +
```

## Checklist anti-revisor Hotmart

- ✅ Sem palavras místicas (alma gemela, brujería, hechizo, magia, espíritu)
- ✅ Disclaimer "fines informativos y entretenimiento" no footer
- ✅ Política de Privacidade detalhada
- ✅ Termos de Uso completos
- ✅ Página de contato com email
- ✅ Idade mínima declarada (18+)
- ✅ Política de reembolso (7 dias)
- ✅ Sem promessas de cura/resultado garantido

## Próximos passos (depois de hospedar)

1. Cadastra produto na Hotmart
2. Configura webhook Hotmart → n8n (`/hotmart-purchase`)
3. Configura template WhatsApp na Meta + conta Postmark
4. Testa fluxo end-to-end com 1 compra fake
